sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{rate:function(t,a){e.show("Rate Calculated")}}});
//# sourceMappingURL=Rate.js.map